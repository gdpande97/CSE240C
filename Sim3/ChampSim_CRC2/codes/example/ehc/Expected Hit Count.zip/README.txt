This folder is like Champsim_CRC2 folder that has been uploaded on the web.
We just added src folder and Makefile into the folder.
The lib and inc folders should be located here to compile correctly.
