/*
 * Block.cpp
 *
 *  Created on: Sep 28, 2016
 *      Author: armin
 */

#include "Block.h"

Block::Block(){
	hit_count = 0;
	rrpv = 0;
}

Block::~Block() {
}
